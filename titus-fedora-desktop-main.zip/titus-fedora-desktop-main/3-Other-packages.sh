echo "Installing extra packages from file..."
sudo dnf -y install fontawesome-fonts fontawesome-fonts-web firefox arandr