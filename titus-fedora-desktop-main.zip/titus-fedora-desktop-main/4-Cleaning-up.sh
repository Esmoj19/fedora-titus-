echo "Thanks for using Titus-Fedora-Desktop!"
echo "What's next?"
echo "1. Edit ~/.config/polybar/config if your ETH icon is not showing up"
sleep 10
sudo reboot 